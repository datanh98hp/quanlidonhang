
<div>
    <?php echo e($title); ?>

    <!-- The whole future lies in uncertainty: live immediately. - Seneca -->
    
</div><?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/components/header.blade.php ENDPATH**/ ?>