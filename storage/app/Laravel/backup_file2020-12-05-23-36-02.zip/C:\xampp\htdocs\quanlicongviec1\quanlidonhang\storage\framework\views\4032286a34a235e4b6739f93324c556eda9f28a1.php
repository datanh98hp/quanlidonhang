<div>
    <form id="formXoa" action="/del-kh/<?php echo e($id); ?>" method="POST">
        <?php echo e(@csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
    </form>
</div>
 
<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
  <script type="text/javascript">
    $(document).ready(function(){
        $("button").trigger('click');
    });
  </script>
    <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/danhmuc/khachhang/xoa-kh.blade.php ENDPATH**/ ?>