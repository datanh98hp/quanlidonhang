 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    


   
    <style>
        .selected{
            background-color: slategrey;
            cursor: pointer;
        }
        .center {
                    display: block;
                    margin-left: 25%;
                    margin-right: auto;
                    width: 50%;
                }
    </style>
    <div class="card mb-3 center" style="max-width: 540px;">
        <div class="row no-gutters">
          <div class="col-md-4">
            <img src="https://cdn.onlinewebfonts.com/svg/img_452000.png" class="card-img" alt="...">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">Thông tin chi tiết</h5>
              <p class="card-text name_display"></p>
              <p class="card-text pos_display"></p>
              <p class="card-text phone_display"></p>
              <b class="card-text luong_display"></b>
              <br/>
              <br/>
              
            <button class="btn btn-success btn_tinhluong" onclick="Tinhluong()">Tính lương</button>
            </div>
           
          </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Thêm mới nhân viên</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="/create-nhanvien" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Họ tên:</label>
                  <input type="text" class="form-control" id="recipient-name" name="Hoten" placeholder="Họ và tên">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label">Giới tính:</label>
                    <select class="custom-select" id="" name="Gioitinh" required>
                      <option selected >Chọn...</option>
                      <option value="0">Nam</option>
                      <option value="1">Nữ</option>
                      
                    </select>
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Địa chỉ:</label>
                <input type="text" class="form-control" id="recipient-name" name="Diachi" placeholder="Địa chỉ">
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Email:</label>
                <input type="text" class="form-control" id="recipient-name" name="Email" placeholder="Email">
              </div>
                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">SDT:</label>
                  <input type="text" class="form-control" id="recipient-name" name="sdt" placeholder="SDT">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label">Thời gian bắt đầu làm việc</label>
                  <input type="date" class="form-control" id="message-text" name="start_work">
                </div>
                <div class="form-group">
                    <label for="message-text" class="col-form-label">Thời gian kết thúc làm việc</label>
                    <input type="date" class="form-control" id="message-text" name="end_work">
                </div>
                <div class="form-group">
                    <label for="message-text" class="col-form-label">Vị trí làm việc</label>
                      <select class="custom-select" id="inputGroupSelect01" name="Position" required>
                        <option selected >Chọn...</option>
                        <option value="admin">Admin</option>
                        <option value="ketoan">KẾ TOÁN</option>
                        <option value="designer">DESIGNER</option>
                        <option value="thi_cong">Thi công</option>
                      </select>
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label">Số $/ giờ</label>
                  <input type="text" class="form-control" id="message-text" name="luong_h">
              </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Lưu</button>
                </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>
      
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table mr-1"></i>
           <span>Danh sách nhân viên</span>
           
        </div>
        <?php if(session('statusBC')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('statusBC')); ?>

        </div>
        <?php endif; ?>
        <div class="card-body">
          <div class=" d-flex justify-content-end">
          <div class="justify-content-sm-center">
            <div class="left" id="formTgBC">
                <form action="/bao-cao-ds-nhanvien" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="form-row align-items-baseline">
                    <div class="col-sm-5 my-1">
                      
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Từ ngày</div>
                        </div>
                        <input type="date" class="form-control" name="startdate" id="" placeholder="Username">
                      </div>
                    </div>
                    <div class="col-sm-5 my-auto">
                    
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">Đến ngày</div>
                        </div>
                        <input type="date" class="form-control" id="" name="enddate" placeholder="Username">
                      </div>
                    </div>
                    <div class="col-sm-2">
                      <button type="submit" class="btn btn-success">In Bảng lương</button>
                    </div>
                  </div>
                </form>
            </div>
          </div>
            
         </div>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">Thêm mới</button>
            <?php if(session('status')): ?>
                  <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
              <?php endif; ?>
            <div class="table-responsive-md text-center" style="margin: 0% 5% 0% 5%">
                
                
                <table class="table table-bordered display" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Họ Tên</th>
                            <th>SDT</th>
                            <th>Ngày vào làm</th>
                            <th>Ngày kết thúc</th>
                            <th>Số ngày làm</th>
                            <th>Hệ số lương</th>
                            <th>Lương/h</th>
                            <th>Pos</th>
                            <th class="luong_display">Lương thực lĩnh</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $nhanvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->Hoten); ?></td>
                            <th><?php echo e($item->sdt); ?></th>
                            <td><?php echo e($item->start_work); ?></td>
                            <td><?php echo e($item->end_work); ?></td>
                            <td><?php echo e(floor( abs(strtotime($item->start_work) - strtotime($item->end_work) ) /(60*60*24) )); ?></td>
                            <?php switch($item->Position):
                              case ('admin'): ?>
                                <td>2</td>
                                  <?php break; ?>

                              <?php case ('ketoan'): ?>
                              <td>1.5</td>
                                  <?php break; ?>

                              <?php default: ?>
                              <td>1</td>
                          <?php endswitch; ?>
                            
                            
                            <td><?php echo e($item->luong_h); ?></td>
                            <td><?php echo e($item->Position); ?></td>
                            <td class="luong_display"><?php echo e(number_format($item->Tienluong)); ?> VND </td>
                            <td>
                            <a class="btn btn-warning" href="/edit-nhanvien/<?php echo e($item->id); ?>"><i class="far fa-edit"></i></a>
                            </td>
                            <td>
                            <form action="/del-nhanvien/<?php echo e($item->id); ?>" method="POST">
                              <?php echo e(@csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <button class="btn btn-danger" type="submit"><i class="fas fa-trash-alt"></i></button>
                            </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-link" href="/print-ds-nhanvien"> <i class="fas fa-print"></i> In danh sách nhân viên</a>
        </div>
    </div>
    <script>
        $(document).ready(function() {
        var table = $('#dataTable').DataTable({
          "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Vietnamese.json"
        }
        });
        $('.btn_tinhluong').hide();
        $('.luong_display').hide();
    $('#dataTable tbody').on('click', 'tr', function () {
        var data = table.row( this ).data();
        // alert( 'You clicked on '+data ); 
        // $('.data_display').text(data);

        $('.name_display').text('Họ tên: '+data[1]);
        $('.pos_display').text('Pos: '+data[8]);
        $('.phone_display').text('SDT : '+data[2]);
        $('.btn_tinhluong').show();  
        $('.luong_display').text('Lương:  '+data[9]);
        if ( $(this).hasClass('selected') ) {
          
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    
   
} );
function Tinhluong(){
      $('.luong_display').show();

    }
    </script>
   
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec1\resources\views/Nhanvien/Nhanvien.blade.php ENDPATH**/ ?>