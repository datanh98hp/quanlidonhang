 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <?php if(session('statusKH')): ?>
      <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <div class="form-group">
    <h2 class="text-center mx-4" style="color: crimson;font-weight: 800">Danh mục Khách hàng</h2>
      <form action="/create-kh" method="POST">
        <?php echo csrf_field(); ?>
          <table class="table table-striped" id="exampleKH">
            <thead>
              <tr>           
                <th scope="">Họ tên KH</th>
                <th scope="">SDT</th>
                <th scope="">Email</th>
                <th scope="">Loại KH</th>
                <th scope="">C.ty</th>
                <th scope=""></th>
              </tr>
            </thead>
          
            <tbody id="content" >
              
                <tr>
                  <td>
                    <input type="text" class="form-control"   name="Hoten" value="">
                  </td>
                  <td>
                    <input type="text" class="form-control"  name="SDT" value="">
                  </td>
                  <td>
                      <input type="text" class="form-control"  name="Email" value="">
                  </td>
                  <td>
                      
                      <select class="custom-select"  name="typeKH" value="">
                          <option value="Thường">Thường</option>
                          <option value="Khách quen" >Khách quen</option>
                          <option value="VIP">VIP</option>
                      </select>
                      
                  </td>
                  <td>
                      <input type="text" class="form-control" name="Cty" value="">
                  </td>
                  <th scope="">
                    <button type="submit" class="btn addRow"><i class="fas fa-plus"></i></button>
                    
                  </th>

                </tr>
                <?php $__currentLoopData = $kh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($item->Hoten); ?></td>
                  <td><?php echo e($item->SDT); ?></td>
                  <td><?php echo e($item->Email); ?></td>
                  <td><?php echo e($item->typeKH); ?></td>
                  <td><?php echo e($item->Cty); ?></td>
                  <td>
                    
                    <a type="button" href="/edit-kh/<?php echo e($item->id); ?>" class="btn"><i class="far fa-edit"></i></a>

                    <a href="/del-kh/<?php echo e($item->id); ?>" type="submit" class="btn  "><i class="fas fa-trash-alt"></i></a>
                  </td>
                
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          
          </table>
      </form>
    </div>

    
    <hr>
    
    <div class="form-group">
      <h2 class="text-center mx-4" style="color: teal;font-weight: 800">Vật liệu</h2>
        <form action="/create-vl" method="POST">
          <?php echo csrf_field(); ?>
            <table class="table table-striped" id="exampleVL">
              <thead>
                <tr>           
                  <th scope="">#</th>
                  <th scope="">Tên VL</th>
                  <th scope="">SL Tồn </th>
                  <th scope="">Don_gia</th>
                  <th scope="">Donvi_tinh</th>
                  <th scope="">NCC</th>
                  <th scope=""></th>
                </tr>
              </thead>
            
              <tbody id="content" >
                
                  <tr>
                    <td>
                    </td>
                    <td>
                      <input type="text" class="form-control"   name="TenVL" value="">
                    </td>
                    <td>
                      <input type="number" min="0" class="form-control"  name="Soluong_ton" value="" >
                    </td>
                    <td>
                        <input type="number" min="0" class="form-control"  name="Don_gia" value="">
                    </td>
                    <td>
                        
                        <select class="custom-select"  name="Donvi_tinh" value="">

                            <option selected>Chọn...</option>
                            <option value="Cái">Cái</option>
                            <option value="Cuộn">Cuộn</option>
                            <option value="Tấm">Tấm</option>
                            <option value="Mét vuông">Mét vuông</option>
                            <option value="Khác">Khác</option>

                        </select>
                        
                    </td>
                    <td>
                        
                        <select class="custom-select"  name="id_ncc" value="">
                          <option value="">Chọn</option>
                            <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->TenNCC); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </select>
                    </td>
                    <td scope="">
                      <button type="submit" class="btn addRow"><i class="fas fa-plus"></i></button>
                    </td>
                  </tr>
                  
                  <?php $__currentLoopData = $vl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <?php echo e($item->id); ?>

                    </td>
                    <td>
                      <?php echo e($item->TenVL); ?>

                    </td>
                    <td>
                      <?php echo e($item->Soluong_ton); ?>

                    </td>
                    <td>
                      <?php echo e($item->Don_gia); ?>

                    </td>
                    <td>
                      <?php echo e($item->Donvi_tinh); ?>

                    </td>
                    <td>
                      <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($nc->id===$item->id_ncc): ?>
                            <?php echo e($nc->TenNCC); ?>

                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td scope="">
                      <a type="button" href="/edit-vl/<?php echo e($item->id); ?>" class="btn"><i class="far fa-edit"></i></a>

                      <a href="/del-vl/<?php echo e($item->id); ?>" type="submit" class="btn"><i class="fas fa-trash-alt"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </tbody>
            
            </table>
        </form>
      </div>
    <hr>
    
     <?php if(session('statusBG')): ?>
       <div class="alert alert-success" role="alert">
             <?php echo e(session('statusBG')); ?>

       </div>
     <?php endif; ?>
    <h2 class="text-center" style="color: blue;font-weight: 800">Báo giá loại mặt hàng</h2>
    
      <div class="form-group">
            <form action="/create-bg" method="POST">
              <?php echo csrf_field(); ?>
                <table class="table table-striped" id="exampleBG">
                  <thead>
                    <tr>           
                      <th scope="">TenLoai</th>
                      <th scope="">Dongia</th>
                      <th scope="">Donvi</th>
                      <th scope=""></th>
                    </tr>
                  </thead>
                
                  <tbody id="content" >
                    
                      <tr>
                        <td>
                          <input type="text" class="form-control"  name="TenLoai" value="">
                        </td>
                        <td>
                          <input type="text" class="form-control"  name="Dongia" value="">
                        </td>
                        <td>
                            
                            <select class="custom-select" name="Donvi">
                              <option selected>Chọn...</option>
                              <option value="Cái">Cái</option>
                              <option value="Cuộn">Cuộn</option>
                              <option value="Tấm">Tấm</option>
                              <option value="Mét vuông">Mét vuông</option>
                              <option value="Khác">Khác</option>
                            </select>
                            
                        </td>
                      
                        <th scope="">
                          <button type="submit" class="btn addRow"><i class="fas fa-plus"></i></button>
                        </th>
      
                      </tr>
                      <?php $__currentLoopData = $bg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->TenLoai); ?></td>
                        <td><?php echo e(number_format($item->Dongia)); ?></td>
                        <td><?php echo e($item->Donvi); ?></td>
                        <td>
                          
                          <a type="button" href="/edit-bg/<?php echo e($item->id); ?>" class="btn"><i class="far fa-edit"></i></a>
      
                          <a href="/del-bg/<?php echo e($item->id); ?>" type="submit" class="btn  "><i class="fas fa-trash-alt"></i></a>
                        </td>
                      
                      </tr>
                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
                  </tbody>
                
                </table>
            </form>
           </div>
     
      
      <hr>
    
      <?php if(session('statusBG')): ?>
      <div class="alert alert-success" role="alert">
            <?php echo e(session('statusNCC')); ?>

      </div>
      <?php endif; ?>
      <h2 class="text-center" style="color:orangered;font-weight: 800">Nhà cung cấp</h2>
            
    <div class="form-group">
            <form action="/create-kh" method="POST">
              <?php echo csrf_field(); ?>
                <table class="table table-striped" id="exampleNCC">
                  <thead>
                    <tr>           
                      <th scope="">Tên Nhà cung cấp</th>
                      <th scope="">Địa chỉ</th>
                      <th scope="">Hotline</th>
                      <th scope="">Đại diện</th>
                      <th scope=""></th>
                    </tr>
                  </thead>
                
                  <tbody id="content" >
                    
                      <tr>
                        <td>
                          <input type="text" class="form-control"   name="TenNCC" value="">
                        </td>
                        <td>
                          <input type="text" class="form-control"  name="DiaChi" value="">
                        </td>
                        <td>
                            <input type="text" class="form-control"  name="Hotline" value="">
                        </td>
                        <td>
                            <input type="text" class="form-control" name="Daidien" value="">
                        </td>
                        <th scope="">
                          <button type="submit" class="btn addRow"><i class="fas fa-plus"></i></button>
                          
                        </th>
      
                      </tr>
                      <?php $__currentLoopData = $ncc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->TenNCC); ?></td>
                        <td><?php echo e($item->DiaChi); ?></td>
                        <td><?php echo e($item->Hotline); ?></td>
                        <td><?php echo e($item->Daidien); ?></td>
                        <td>
                          
                          <a type="button" href="/edit-ncc/<?php echo e($item->id); ?>" class="btn"><i class="far fa-edit"></i></a>
      
                          <a href="/del-ncc/<?php echo e($item->id); ?>" type="submit" class="btn  "><i class="fas fa-trash-alt"></i></a>
                        </td>
                      
                      </tr>
                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
                  </tbody>
                
                </table>
            </form>
    </div>


    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<script>
    $(document).ready(function() {
    $('#exampleKH').DataTable();
    $('#exampleBG').DataTable();
    $('#exampleNCC').DataTable();
    $('#exampleVL').DataTable();
} );

</script>
<?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/danhmuc/Danhmuc.blade.php ENDPATH**/ ?>