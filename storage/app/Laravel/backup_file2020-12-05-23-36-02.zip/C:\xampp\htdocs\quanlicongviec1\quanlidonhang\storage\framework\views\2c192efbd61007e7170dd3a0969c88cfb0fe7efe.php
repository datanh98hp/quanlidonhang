 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row justify-content-center">
        <div class="col-md-8"> 
            <form class="form-group" action="/update-bg/<?php echo e($bg->id); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Tên loại:</label>
                  <input type="text" class="form-control" id="recipient-name" name="TenLoai" value="<?php echo e($bg->TenLoai); ?>">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label" >Đơn giá:</label>
                  <input class="form-control" id="" value="<?php echo e($bg->Dongia); ?> " name="Dongia" >
                </div>
                <div class="form-group">
                    
                        <label for="validationTooltip04">Đơn vị</label>
                        <select class="custom-select" id="validationTooltip04" name="Donvi" value="<?php echo e($bg->Donvi); ?>" required>
                            <option value="Cái" <?php if($bg->Donvi==="Cái"): ?>
                                selected="true"
                            <?php else: ?>
                            
                            <?php endif; ?>>Cái</option>
                            <option value="Tờ" <?php if($bg->Donvi==="Tờ"): ?>
                              selected="true"
                          <?php else: ?>
                         
                          <?php endif; ?>>Tờ</option>
                          <option value="Mét vuông" <?php if($bg->Donvi==="Mét vuông"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>Mét vuông</option>
                        <option value="Hộp" <?php if($bg->Donvi==="Hộp"): ?>
                            selected="true"
                        <?php else: ?>
                       
                        <?php endif; ?>>Hộp</option>
                        </select>
                        <div class="invalid-tooltip">
                         Nhập đầy đủ thông tin
                        </div>
        
                </div>
                
                <div class="form-group">
                    <button class="btn btn-success">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    
<?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/danhmuc/banggia/Edit-loai-mh.blade.php ENDPATH**/ ?>