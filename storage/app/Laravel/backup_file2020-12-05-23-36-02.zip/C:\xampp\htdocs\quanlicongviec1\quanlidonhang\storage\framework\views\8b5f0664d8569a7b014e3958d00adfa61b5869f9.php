 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    
    <div class="card border-secondary mb-3 center" style="width: 60rem; ">
      <div class="card-body">
        <h5 class="card-title"><span>Nhân viên : <?php echo e($nhanvien->Hoten); ?></span></h5>
        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($nhanvien->Position); ?></h6>
        <form action="/update-nhanvien/<?php echo e($nhanvien->id); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('PUT')); ?>

              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Họ tên:</label>
                <input type="text" class="form-control" id="recipient-name" name="Hoten" value="<?php echo e($nhanvien->Hoten); ?>" placeholder="Họ và tên">
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">SDT:</label>
                <input type="text" class="form-control" id="recipient-name" value="<?php echo e($nhanvien->sdt); ?>" name="sdt" placeholder="SDT">
              </div>
              <div class="form-group">
                <label for="message-text" class="col-form-label">Thời gian bắt đầu làm việc</label>
                <input type="datetime-local" class="form-control" value="<?php echo e($nhanvien->start_work); ?>" id="message-text" name="start_work">
              </div>
              <div class="form-group">
                  <label for="message-text" class="col-form-label">Thời gian kết thúc làm việc</label>
                  <input type="datetime-local" class="form-control" value="<?php echo e($nhanvien->start_work); ?>"  id="message-text" name="end_work">
              </div>
              <div class="form-group">
                  <label for="message-text" class="col-form-label">Vị trí làm việc</label>
                  
                    <select class="custom-select" id="inputGroupSelect01"  name="Position" required>
                      <option selected value="<?php echo e($nhanvien->Position); ?>">Chọn...</option>
                      <option value="admin">Admin</option>
                      <option value="ketoan">KẾ TOÁN</option>
                      <option value="designer">DESIGNER</option>
                      <option value="thi_cong">Thi công</option>
                    </select>
              </div>
              <div class="form-group">
                <label for="message-text" class="col-form-label">Số $/ giờ</label>
                <input type="text" class="form-control" id="message-text" value="<?php echo e($nhanvien->luong_h); ?>" name="luong_h">
            </div>
              <div class="modal-footer">
                
                <button type="submit" class="btn btn-primary">Lưu</button>
              </div>
            </form>
      </div>
    </div>
      
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/Nhanvien/Edit-nhanvien.blade.php ENDPATH**/ ?>