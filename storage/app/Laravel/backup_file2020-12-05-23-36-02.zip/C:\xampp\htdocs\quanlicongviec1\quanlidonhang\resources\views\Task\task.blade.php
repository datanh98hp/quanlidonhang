<x-app-layout>

<iframe src="{{url('event')}}" width="100%" height="810px"></iframe>
       
</x-app-layout>
