<div>
  <div class="card text-center" style="width: 60rem;margin:0% 15% 10% ">
    <div class="card-body">
      <h5 class="card-title">Date: </h5>
      <!-- When there is no desire, all things are at peace. - Laozi -->
    <div class="row">
      <img src="https://pngimage.net/wp-content/uploads/2018/06/webpack-logo-png.png" width="15%" alt="logo">
      <div class="justify-content-center" style="margin-left:1%;">
          <h2 class="text-center" style="font-family: 'Lexend Peta', sans-serif;color: red">TRUNG TÂM QUẢNG CÁO TRẺ</h2>
          <h1 class="text-center" style="font-family: 'Bungee Inline', cursive;color: red">Thiện Phúc</h1>
          <span style="color: red">DC: Số 73 Trần Tất Văn - TT. An Lão - Hải Phòng * SDT: 0965 054 109 - 0867 10 03 89 </span>
      </div>
      <h3 class="center" style=" color: red;margin-left:35%;margin-top:10px;font-family: 'Alfa Slab One', cursive;" >HÓA ĐƠN ĐẶT HÀNG</h3>
     
  </div>
  <h6 class="text-center">THIẾT KẾ - HOÀN THIỆN BIỂN QUẢNG CÁO THEO YÊU CẦU - IN TRÊN MỌI CHẤT LIỆU - IN PHUN KHỔ LỚN - 
      IN OFFSET - CÂT CHỮ VI TÍNH - CẤT CHỮ MICA NỔI - LẮP ĐÈN NEON SIGN - IN THIỆP CƯỚI - GIẤY KHEN - GIẤY MỜI - IN ẢNH ...
  </h6>
  <hr color="lightred">
  <div class="collunm">
      <h5>Người đặt hàng:<p class="name_oder"></p></h5>
      <h5>Địa chỉ: <p class="address_oder"></p></h5>
      <table class="table display" id="table-bill" style="width:100%">
          <thead class="thead-light">
            <tr>
              <th scope="col">TT</th>
              <th scope="col">Tên hàng</th>
              <th scope="col">KT</th>
              <th scope="col">Đơn giá</th>
              <th scope="col">Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
              <td>5000 VND</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
              <td>5000 VND</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
              <td>5000 VND</td>
            </tr>
          </tbody>
          <span class="total_data"></span>
      </table>
  </div>
    </div>
  </div>
    
    
</div><?php /**PATH C:\xampp\htdocs\quanlicongviec\resources\views/components/detail-bill.blade.php ENDPATH**/ ?>